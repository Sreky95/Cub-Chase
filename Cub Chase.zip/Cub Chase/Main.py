from PyQt5.QtWidgets import (QMainWindow, QFrame, QDesktopWidget, QApplication, QHBoxLayout, QGridLayout,
                             QVBoxLayout, QWidget, QPushButton, QLabel, QStackedLayout)
from PyQt5.QtCore import Qt, QBasicTimer, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QPixmap
import sys, random, math


class GameWindow(QWidget):

    def __init__(self, parent):
        super().__init__()
        self.setWindowTitle("Cub Chase")
        self.parent = parent
        self.FreeSpaces = 0

        layout = QGridLayout(self)
        layout.setSpacing(0)

        terrainwidth = 15
        terrainheight = 15

        self.TerrainMatrix = [[0 for x in range(terrainwidth)] for y in range(terrainheight)]
        for i in range(len(self.TerrainMatrix)):
            for j in range(len(self.TerrainMatrix[i])):
                if i == 0 or i == terrainwidth - 1 or j == 0 or j == terrainheight - 1:
                    self.TerrainMatrix[i][j] = TerrainTile(layout, self, 0, [i, j])
                else:
                    if i == math.floor(terrainwidth/2) and j == math.floor(terrainheight/2):
                        self.TerrainMatrix[i][j] = TerrainTile(layout, self, 2, [i, j])
                    else:
                        self.TerrainMatrix[i][j] = TerrainTile(layout, self, random.randint(0,2), [i,j])

        self.NPC1X = 0
        self.NPC1Y = 0
        self.NPC1 = NPC(self, self.TerrainMatrix, self.FreeSpaces)

    def closeEvent(self, event): #MainWindow podesiti da bude hub. Da ima next level, trenutne bodove, reset igre...

        self.parent.show()
        self.close()


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.title = "Cub Chase"
        self.top = 600
        self.left = 400
        self.width = 680
        self.height = 300

        self.playButton = QPushButton("PLAY", self)
        self.playButton.move(300, 125)
        self.playButton.clicked.connect(self.gameWindow)

        self.main_window()

    def main_window(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.top, self.left, self.width, self.height)
        self.show()

    def gameWindow(self):
        self.mainGameWindow = GameWindow(self)
        self.mainGameWindow.show()
        self.hide()


class TerrainTile(object):

    def __init__(self, layout, parent, terraintype, coordinates):
        self.parent = parent
        self.terrainType = terraintype
        self.coordinates = coordinates
        if terraintype == 0:
            self.passable = False
        else:
            self.passable = True
            self.parent.FreeSpaces = self.parent.FreeSpaces + 1
        self.footPrints = False
        self.PaintTerrainTile(layout)

    def PaintTerrainTile(self, layout):
        print(self.terrainType)
        print(self.coordinates)

        templabel = QLabel()
        if(self.terrainType == 0):
            temppicture = QPixmap("./Wall.jpg")
            templabel.setPixmap(temppicture.scaled(40, 40))
            layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])
        else:
            if (self.terrainType == 1):
                temppicture = QPixmap("./Sand.jpg")
                templabel.setPixmap(temppicture.scaled(40, 40))
                layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])
            else:
                if(self.terrainType == 2):
                    temppicture = QPixmap("./Grass.jpg")
                    templabel.setPixmap(temppicture.scaled(40, 40))
                    layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])

class NPC(QLabel):

    def __init__(self, parent, TerrainMatrix, FreeSpaces):
        super().__init__(parent)
        self.parent = parent
        self.TerrainMatrix = TerrainMatrix
        self.speed = 0
        tempVar = random.randint(0, FreeSpaces)
        for i in range(len(self.TerrainMatrix)):
            for j in range(len(self.TerrainMatrix[i])):
                if self.TerrainMatrix[i][j].terrainType > 0:
                    if tempVar == 1:
                        self.x = i
                        self.y = j
                    else:
                        tempVar = tempVar - 1

        """self.spawned = False
        while(self.spawned == False):
            tempVar = random.randint(0, 15*15)
            if TerrainMatrix[tempVar].TerrainType > 0:
                self.x = TerrainMatrix[tempVar].Coordinates[0]
                self.y = TerrainMatrix[tempVar].Coordinates[1]
                self.spawned = True"""

        self.Model = QPixmap("./Circle.jpg")
        self.setPixmap(self.Model)
        self.setGeometry(10, 10, 40, 40)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    sys.exit(app.exec_())
