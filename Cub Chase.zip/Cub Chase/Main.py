from PyQt5.QtWidgets import (QMainWindow, QFrame, QDesktopWidget, QApplication, QHBoxLayout, QGridLayout,
                             QVBoxLayout, QWidget, QPushButton, QLabel, QStackedLayout)
from PyQt5.QtCore import Qt, QBasicTimer, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QPixmap
import sys, random, math


class GameWindow(QWidget):

    def __init__(self, parent):
        super().__init__()
        self.setWindowTitle("Cub Chase")
        self.parent = parent

        mainLayout = QStackedLayout(self)
        tempwidget = QWidget(self)
        layout = QGridLayout(self) #Promeniti da bude grid layout u QStackedLayout metodom layour.addLayout(Grid...)
        layout.setSpacing(0)

        terrainwidth = 13
        terrainheight = 13

        self.TerrainMatrix = [[0 for x in range(terrainwidth)] for y in range(terrainheight)]
        for i in range(len(self.TerrainMatrix)):
            for j in range(len(self.TerrainMatrix[i])):
                if i == 0 or i == terrainwidth - 1 or j == 0 or j == terrainheight - 1:
                    self.TerrainMatrix[i][j] = TerrainTile(layout, 0, [i, j])
                else:
                    if i == math.floor(terrainwidth/2) and j == math.floor(terrainheight/2):
                        self.TerrainMatrix[i][j] = TerrainTile(layout, 2, [i, j])
                    else:
                        self.TerrainMatrix[i][j] = TerrainTile(layout, random.randint(0,2), [i,j])

        tempwidget.setLayout(layout)
        mainLayout.addWidget(tempwidget)
        templabel = QLabel()
        temppicture = QPixmap("./Sand.jpg")
        templabel.setPixmap(temppicture.scaled(30, 30))
        mainLayout.addWidget(templabel)
        self.setLayout(mainLayout)

    def closeEvent(self, event): #MainWindow podesiti da bude hub. Da ima next level, trenutne bodove, reset igre...

        self.parent.show()
        self.close()


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.title = "Cub Chase"
        self.top = 600
        self.left = 400
        self.width = 680
        self.height = 300

        self.playButton = QPushButton("PLAY", self)
        self.playButton.move(300, 125)
        self.playButton.clicked.connect(self.gameWindow)

        self.main_window()

    def main_window(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.top, self.left, self.width, self.height)
        self.show()

    def gameWindow(self):
        self.mainGameWindow = GameWindow(self)
        self.mainGameWindow.show()
        self.hide()


class TerrainTile(object):

    def __init__(self, layout, terraintype, coordinates):
        self.terrainType = terraintype
        self.coordinates = coordinates
        if terraintype == 0:
            self.passable = False
        else:
            self.passable = True
        self.footPrints = False
        self.PaintTerrainTile(layout)

    def PaintTerrainTile(self, layout):
        print(self.terrainType)
        print(self.coordinates)

        templabel = QLabel()
        if(self.terrainType == 0):
            temppicture = QPixmap("./Wall.jpg")
            templabel.setPixmap(temppicture.scaled(50, 50))
            layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])
        else:
            if (self.terrainType == 1):
                temppicture = QPixmap("./Sand.jpg")
                templabel.setPixmap(temppicture.scaled(50, 50))
                layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])
            else:
                if(self.terrainType == 2):
                    temppicture = QPixmap("./Grass.jpg")
                    templabel.setPixmap(temppicture.scaled(50, 50))
                    layout.addWidget(templabel, self.coordinates[0], self.coordinates[1])


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    sys.exit(app.exec_())
